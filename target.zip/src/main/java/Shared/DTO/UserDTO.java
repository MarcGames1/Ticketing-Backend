package Shared.DTO;

public class UserDTO {
    public Long id;
    public String firstName;
    public String lastName;
}
