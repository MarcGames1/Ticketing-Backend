package Enums;

public enum TaskStatus {
    Pending,
    InProgress,
    Completed
}
