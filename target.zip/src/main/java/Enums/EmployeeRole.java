package Enums;

public enum EmployeeRole {
    MANAGER,  // big BO$$
    EMPLOYEE, // WORKER / poor people
    SUPERVISOR // little boss
}