package Task.DTO;

public class TaskTicketDTO {
    public Long id;
    public String title;
    public String content;
}
